$(document).ready(function(){
$("#content").fadeIn(800);
setTimeout(function(){$("form").removeClass("loading");},2000);	
});

