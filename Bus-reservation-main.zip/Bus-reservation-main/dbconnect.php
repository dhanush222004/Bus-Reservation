<?php
    $conn=mysqli_connect('localhost','root','','booking_db');
    if(!$conn){
        echo"database failed to open....";
    }

    ?>